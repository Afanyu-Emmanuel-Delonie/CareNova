public class BankAccountTest {

    private BankAccount account;
    private int passed = 0;
    private int failed = 0;

    public void setUp() {
        account = new BankAccount("John Doe", 1000.00);
    }

    public void tearDown() {
        System.out.println("Test completed.");
    }

    private static void assertEquals(double expected, double actual, String message) {
        double epsilon = 1e-9;
        if (Math.abs(expected - actual) > epsilon) {
            throw new AssertionError(message + " (expected: " + expected + ", actual: " + actual + ")");
        }
    }

    private static void assertEquals(String expected, String actual, String message) {
        if (!expected.equals(actual)) {
            throw new AssertionError(message + " (expected: " + expected + ", actual: " + actual + ")");
        }
    }

    @FunctionalInterface
    private interface ThrowingRunnable {
        void run() throws Exception;
    }

    private static void assertThrows(Class<? extends Throwable> expected, ThrowingRunnable action, String message) {
        try {
            action.run();
            throw new AssertionError(message + " (expected exception: " + expected.getSimpleName() + ")");
        } catch (Throwable ex) {
            if (!expected.isInstance(ex)) {
                throw new AssertionError(message + " (unexpected exception: " + ex + ")");
            }
        }
    }

    public void testInitialBalance() {
        assertEquals(1000.00, account.getBalance(), "Initial balance should be 1000.00");
    }

    public void testAccountHolder() {
        assertEquals("John Doe", account.getAccountHolder(), "Account holder should be John Doe");
    }

    public void testDeposit() {
        account.deposit(500.00);
        assertEquals(1500.00, account.getBalance(), "Balance after deposit should be 1500.00");
    }

    public void testWithdraw() {
        account.withdraw(200.00);
        assertEquals(800.00, account.getBalance(), "Balance after withdrawal should be 800.00");
    }

    public void testDepositNegativeAmount() {
        assertThrows(IllegalArgumentException.class, () -> account.deposit(-100.00),
                "Depositing a negative amount should throw IllegalArgumentException");
    }

    public void testWithdrawInsufficientFunds() {
        assertThrows(IllegalArgumentException.class, () -> account.withdraw(5000.00),
                "Withdrawing more than balance should throw IllegalArgumentException");
    }

    public void testNegativeInitialBalance() {
        assertThrows(IllegalArgumentException.class, () -> new BankAccount("Jane Doe", -500.00),
                "Negative initial balance should throw IllegalArgumentException");
    }

    private void runTest(String name, Runnable test) {
        setUp();
        try {
            test.run();
            passed++;
            System.out.println("[PASS] " + name);
        } catch (Throwable ex) {
            failed++;
            System.out.println("[FAIL] " + name + " -> " + ex.getMessage());
        } finally {
            tearDown();
        }
    }

    private int runAll() {
        runTest("testInitialBalance", this::testInitialBalance);
        runTest("testAccountHolder", this::testAccountHolder);
        runTest("testDeposit", this::testDeposit);
        runTest("testWithdraw", this::testWithdraw);
        runTest("testDepositNegativeAmount", this::testDepositNegativeAmount);
        runTest("testWithdrawInsufficientFunds", this::testWithdrawInsufficientFunds);
        runTest("testNegativeInitialBalance", this::testNegativeInitialBalance);

        System.out.println("Passed: " + passed + ", Failed: " + failed);
        return failed;
    }

    public static void main(String[] args) {
        BankAccountTest suite = new BankAccountTest();
        int failedCount = suite.runAll();
        if (failedCount > 0) {
            System.exit(1);
        }
    }
}
